<?php
function format($number)
{
    // Ensure the number is an integer
    $number = (int) $number;
    if (!is_int($number) || $number < 0) {
        return 'Invalid number';
    }

    // Format the number with commas
    return number_format($number);
}
$allowedCategories = ['commertial_rent', 'commertial_sale', 'residential_rent', 'residential_sale'];
$allowedCities = ['islamabad', 'faisalabad', 'lahore', 'okara', 'karachi'];

// Get the category and city from the URL, remove quotes, and convert to lowercase
$category = isset($_GET['category']) ? strtolower(trim($_GET['category'])) : null;
$city = isset($_GET['city']) ? strtolower(trim($_GET['city'])) : null;
$page = isset($_GET['page']) ? (int) $_GET['page'] : 1; // Get the page number, default is 1

$itemsPerPage = 12; // Items per page
$offset = ($page - 1) * $itemsPerPage; // Calculate the offset for the SQL query

function send404()
{
    header("HTTP/1.1 404 Not Found");
    exit();
}

// Validate category
if (!in_array($category, $allowedCategories)) {
    send404();
}

// Validate city
if (!in_array($city, $allowedCities)) {
    send404();
}

// Include the database connection
include 'backend/conn.php';

// Get the total number of records
$countQuery = "SELECT COUNT(*) as total FROM `properties` WHERE `city` = '$city' AND `category` = '$category' ORDER BY `id` DESC";
$countResult = mysqli_query($conn, $countQuery);
$countRow = mysqli_fetch_assoc($countResult);
$totalItems = $countRow['total'];
$totalPages = ceil($totalItems / $itemsPerPage); // Calculate total number of pages

// Query the database to get the 12 items for the current page
$query = "SELECT * FROM `properties` WHERE `city` = '$city' AND `category` = '$category' ORDER BY `id` DESC  LIMIT $itemsPerPage OFFSET $offset";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="style.css">
    <title><?php echo strtoupper($category)?></title>
</head>

<body>
    <?php include 'assets/components/top.php' ?>
    <?php include 'assets/components/nav.php' ?>
    <h1 class="text-capitalize p-3">properties in <span style="color: red;"><?php echo $city ?></span></h1>
    <div class="container-fluid justify-content-around row mb-5">
        <?php
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<a href="projectdetail.php?category=' . $category . '&city=' . $city . '&id=' . $row['id'] . '" style="all:unset;cursor:pointer;"><div class="card col-xxl-3 col-lg-3 col-md-3 col-sm-10 col-10 p-0  border-0 pfr mb-5">
            <img src="' . substr($row['imgAddress'], 6) . '" alt="">
            <div class="card-body text-center fw-semibold text-black ">
                <p class="card-text">
                </p>
                <div>PKR ' . format($row['price']) . '</div>
                <div>' . $row['area'] . '</div>
                <div>
                    <img src="assets/img/shower.png" alt="" class="mb-2">
                    <span class="me-2">' . $row['bathroom'] . '</span>
                    <img src="assets/img/bed.png" alt="" class="mb-1">
                    <span>' . $row['bedroom'] . '</span>
                </div>
                <div>' . $row['location'] . '</div>
                <p></p>
            </div>
        </div></a>';
            }
        } else {
            echo "Not Availabe Right Now";
        }

        ?>
        <!-- <div class="card col-xxl-3 col-lg-3 col-md-3 col-sm-10 col-10 p-0  border-0 pfr mb-5">
            <img src="assets/img/pfri2.png" alt="">
            <div class="card-body text-center fw-semibold text-black ">
                <p class="card-text">
                </p>
                <div>PKR 40,000</div>
                <div>5 Marla</div>
                <div>
                    <img src="assets/img/shower.png" alt="" class="mb-2">
                    <span class="me-2">2</span>
                    <img src="assets/img/bed.png" alt="" class="mb-1">
                    <span>2</span>
                </div>
                <div>Khayaban Colony No. 3</div>
                <p></p>
            </div>
        </div>
        <div class="card col-xxl-3 col-lg-3 col-md-3 col-sm-10 col-10 p-0 border-0 pfr mb-5">
            <img src="assets/img/pfri3.png" alt="">
            <div class="card-body text-center fw-semibold text-black ">
                <p class="card-text">
                </p>
                <div>PKR 40,000</div>
                <div>5 Marla</div>
                <div>
                    <img src="assets/img/shower.png" alt="" class="mb-2">
                    <span class="me-2">2</span>
                    <img src="assets/img/bed.png" alt="" class="mb-1">
                    <span>2</span>
                </div>
                <div>Khayaban Colony No. 3</div>
                <p></p>
            </div>
        </div>
        <div class="card col-xxl-3 col-lg-3 col-md-3 col-sm-10 col-10 p-0 border-0 pfr mb-5">
            <img src="assets/img/pfri1.png" alt="">
            <div class="card-body text-center fw-semibold text-black ">
                <p class="card-text">
                </p>
                <div>PKR 40,000</div>
                <div>5 Marla</div>
                <div>
                    <img src="assets/img/shower.png" alt="" class="mb-2">
                    <span class="me-2">2</span>
                    <img src="assets/img/bed.png" alt="" class="mb-1">
                    <span>2</span>
                </div>
                <div>Khayaban Colony No. 3</div>
                <p></p>
            </div>
        </div> -->
    </div>

    <!-- <div class="container-fluid justify-content-around row mb-5">
        <div class="card col-xxl-3 col-lg-3 col-md-3 col-sm-10 col-10 p-0 border-0 pfr mb-5">
            <img src="assets/img/pfri2.png" alt="">
            <div class="card-body text-center fw-semibold text-black ">
                <p class="card-text">
                </p>
                <div>PKR 40,000</div>
                <div>5 Marla</div>
                <div>
                    <img src="assets/img/shower.png" alt="" class="mb-2">
                    <span class="me-2">2</span>
                    <img src="assets/img/bed.png" alt="" class="mb-1">
                    <span>2</span>
                </div>
                <div>Khayaban Colony No. 3</div>
                <p></p>
            </div>
        </div>
        <div class="card col-xxl-3 col-lg-3 col-md-3 col-sm-10 col-10 p-0 border-0 pfr mb-5">
            <img src="assets/img/pfri3.png" alt="">
            <div class="card-body text-center fw-semibold text-black ">
                <p class="card-text">
                </p>
                <div>PKR 40,000</div>
                <div>5 Marla</div>
                <div>
                    <img src="assets/img/shower.png" alt="" class="mb-2">
                    <span class="me-2">2</span>
                    <img src="assets/img/bed.png" alt="" class="mb-1">
                    <span>2</span>
                </div>
                <div>Khayaban Colony No. 3</div>
                <p></p>
            </div>
        </div>
        <div class="card col-xxl-3 col-lg-3 col-md-3 col-sm-10 col-10 p-0 border-0 pfr mb-5">
            <img src="assets/img/pfri1.png" alt="">
            <div class="card-body text-center fw-semibold text-black ">
                <p class="card-text">
                </p>
                <div>PKR 40,000</div>
                <div>5 Marla</div>
                <div>
                    <img src="assets/img/shower.png" alt="" class="mb-2">
                    <span class="me-2">2</span>
                    <img src="assets/img/bed.png" alt="" class="mb-1">
                    <span>2</span>
                </div>
                <div>Khayaban Colony No. 3</div>
                <p></p>
            </div>
        </div>
    </div>
    <div class="container-fluid justify-content-around row mb-5">
        <div class="card col-xxl-3 col-lg-3 col-md-3 col-sm-10 col-10 p-0 border-0 pfr mb-5">
            <img src="assets/img/pfri2.png" alt="">
            <div class="card-body text-center fw-semibold text-black ">
                <p class="card-text">
                </p>
                <div>PKR 40,000</div>
                <div>5 Marla</div>
                <div>
                    <img src="assets/img/shower.png" alt="" class="mb-2">
                    <span class="me-2">2</span>
                    <img src="assets/img/bed.png" alt="" class="mb-1">
                    <span>2</span>
                </div>
                <div>Khayaban Colony No. 3</div>
                <p></p>
            </div>
        </div>
        <div class="card col-xxl-3 col-lg-3 col-md-3 col-sm-10 col-10 p-0 border-0 pfr mb-5">
            <img src="assets/img/pfri3.png" alt="">
            <div class="card-body text-center fw-semibold text-black ">
                <p class="card-text">
                </p>
                <div>PKR 40,000</div>
                <div>5 Marla</div>
                <div>
                    <img src="assets/img/shower.png" alt="" class="mb-2">
                    <span class="me-2">2</span>
                    <img src="assets/img/bed.png" alt="" class="mb-1">
                    <span>2</span>
                </div>
                <div>Khayaban Colony No. 3</div>
                <p></p>
            </div>
        </div>
        <div class="card col-xxl-3 col-lg-3 col-md-3 col-sm-10 col-10 p-0 border-0 pfr mb-5">
            <img src="assets/img/pfri1.png" alt="">
            <div class="card-body text-center fw-semibold text-black ">
                <p class="card-text">
                </p>
                <div>PKR 40,000</div>
                <div>5 Marla</div>
                <div>
                    <img src="assets/img/shower.png" alt="" class="mb-2">
                    <span class="me-2">2</span>
                    <img src="assets/img/bed.png" alt="" class="mb-1">
                    <span>2</span>
                </div>
                <div>Khayaban Colony No. 3</div>
                <p></p>
            </div>
        </div>
    </div> -->

    <div class="container my-5">
        <div class="pagination-wrapper">
            <?php
            // Previous Button
            if ($page > 1) {
                $prevPage = $page - 1;
                echo '<div class="page-item">
                <a href="?category=' . $category . '&city=' . $city . '&page=' . $prevPage . '" class="page-link">&laquo;</a>
              </div>';
            } else {
                // Disabled "Previous" button
                echo '<div class="page-item disabled">
                <a class="page-link" aria-disabled="true">&laquo;</a>
              </div>';
            }

            // Page Numbers
            for ($i = 1; $i <= $totalPages; $i++) {
                if ($i == $page) {
                    // Current page (highlighted)
                    echo '<div class="page-item active">
                    <a href="#" class="page-link">' . $i . '</a>
                  </div>';
                } else {
                    // Other pages
                    echo '<div class="page-item">
                    <a href="?category=' . $category . '&city=' . $city . '&page=' . $i . '" class="page-link">' . $i . '</a>
                  </div>';
                }
            }

            // Next Button
            if ($page < $totalPages) {
                $nextPage = $page + 1;
                echo '<div class="page-item">
                <a href="?category=' . $category . '&city=' . $city . '&page=' . $nextPage . '" class="page-link">&raquo;</a>
              </div>';
            } else {
                // Disabled "Next" button
                echo '<div class="page-item disabled">
                <a class="page-link" aria-disabled="true">&raquo;</a>
              </div>';
            }
            ?>


            <!-- <div class="page-item ">
                <a href="#" class="page-link">2</a>
            </div>
            <div class="page-item">
                <a href="#" class="page-link">3</a>
            </div>
            <div class="page-item">
                <a href="#" class="page-link">4</a>
            </div>
            <div class="page-item">
                <a href="#" class="page-link">5</a>
            </div> -->

        </div>
    </div>



    <!-- Footer -->
    <footer class="footer mt-5 py-5 bg-footer text-white">
        <div class="container">
            <div class="row p-5">
                <div class="col-lg-3 col-md-6 col-sm-6 col-12 mb-4 mb-md-0">
                    <h5 class="mb-4">Offers</h5>
                    <ul class="list-unstyled">
                        <li><a href="Residential rents.html" class="text-white"><img src="./assets/img/footer-icon.svg"
                                    alt=""> Properties</a></li>
                        <li><a href="Residential sale.html" class="text-white"><img src="./assets/img/footer-icon.svg"
                                    alt=""> Sale</a></li>
                        <li><a href="contact.html" class="text-white"><img src="./assets/img/footer-icon.svg" alt="">
                                Locations</a></li>
                        <li><a href="contact.html" class="text-white"><img src="./assets/img/footer-icon.svg" alt="">
                                Clients Support</a></li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-6 col-12 mb-4 mb-md-0">
                    <h5 class="mb-4">Company</h5>
                    <ul class="list-unstyled">
                        <li><a href="index.html" class="text-white"><img src="./assets/img/footer-icon.svg" alt="">
                                Home</a></li>
                        <li><a href="About us.html" class="text-white"><img src="./assets/img/footer-icon.svg" alt="">
                                About</a></li>
                        <li><a href="blog.html" class="text-white"><img src="./assets/img/footer-icon.svg" alt="">
                                Blog</a></li>
                        <li><a href="contact.html" class="text-white"><img src="./assets/img/footer-icon.svg" alt="">
                                Contact Us</a></li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-6 col-12 mt-lg-0 mt-md-4 mt-sm-4 mb-4 mb-md-0">
                    <h5 class="mb-4">Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-white"><img src="./assets/img/footer-icon.svg" alt=""> Terms &
                                Conditions</a></li>
                        <li><a href="#" class="text-white"><img src="./assets/img/footer-icon.svg" alt=""> User's
                                Guide</a></li>
                        <li><a href="contact.html" class="text-white"><img src="./assets/img/footer-icon.svg" alt="">
                                Support Center</a></li>
                        <li><a href="Projects.html" class="text-white"><img src="./assets/img/footer-icon.svg" alt="">
                                Projects</a></li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-6 col-12 mt-lg-0 mt-md-4 mt-sm-4 mb-4 mb-md-0">
                    <h5 class="mb-4">Have a Questions?</h5>
                    <p>203 Fake St. Mountain View,California, USA</p>
                    <p>+2 392 3929 210</p>
                    <p>info@yourdomain.com</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- Copyright -->
    <div class="bg-dark text-center text-white py-3">
        <p class="mb-0">Copyright &copy;2024 All right reserved</p>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
</body>

</html>