<?php 
function format($number)
{
    // Ensure the number is an integer
    $number = (int) $number;
    if (!is_int($number) || $number < 0) {
        return 'Invalid number';
    }

    // Format the number with commas
    return number_format($number);
}
$allowedCategories = ['commertial_rent', 'commertial_sale', 'residential_rent', 'residential_sale'];
$allowedCities = ['islamabad', 'faisalabad', 'lahore', 'okara','karachi'];

$category = isset($_GET['category']) ? strtolower(trim($_GET['category'])) : null;
$city = isset($_GET['city']) ? strtolower(trim($_GET['city'])) : null;
$id = isset($_GET['id']) ? $_GET['id'] : null;

function send404() {
    header("HTTP/1.1 404 Not Found");
    exit();
}

// Validate category
if (!in_array($category, $allowedCategories)) {
    send404();
}

// Validate city
if (!in_array($city, $allowedCities)) {
    send404();
}

// Validate id (must be numeric)
if (!is_numeric($id)) {
    send404();
}

include 'backend/conn.php';

$query = "SELECT * FROM `properties` WHERE `city` = '$city' AND `category` = '$category' AND `id` = $id";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

    <title>Projects</title>
</head>

<body>
<!-- Header -->
<?php include 'assets/components/top.php'?>
<?php include 'assets/components/nav.php'?>

  <!-- -----------------Our Projects---------------- -->
  <div class="container text-center mb-5 mt-xxl-2 mt-xl-3 mt-lg-4 mt-md-4 mt-sm-4">
    <span class="title mt-4 pe-2" style="border-bottom: 4px solid #FF573B;">Project</span><span class="title" style="color: #FF573B;">Detail</span>
  </div>

  <div class="container property-detail">
    <div class="row">
        <div class="col-md-6 mt-2">
            <div class="property-images">
                <img src="<?php echo substr($row['imgAddress'],6)?>" class="img-fluid main-image" alt="Property Main Image">
                
            </div>
        </div>
        <div class="col-md-6  mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-sm-4">
            <div class="property-details">
                <h2 class="property-title"><?php echo  $row['title'] ?></h2>
                <p class="property-location">Location: &nbsp;&nbsp; <?php echo $row['location'] ?></p>
                <p class="property-price">Price: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Rs <?php echo format($row['price'])?></p>
                <p class="property-size">Plot size:&nbsp;&nbsp;&nbsp; <?php echo $row['area']?></p>
                <p class="property-bed-bath"><?php echo $row['bedroom']?> Bedrooms, <?php echo $row['bathroom']?> Bathrooms</p>
                
                <h5>Type :</h5>
                <p class="landmarks"><?php echo $row['type']?></p>
                
                <h5>Description:</h5>
                <ul class="amenities-list">
                    <li><?php echo $row['description']?></li>
                </ul>


                <!-- <p class="property-description">
                    A spacious 3-bedroom apartment located in the heart of Downtown. Features include living area, kitchen, and access to a variety of amenities.
                </p> -->

                <div class="contact-info">
                    <p>Contact Agent: John Doe</p>
                    <p>Phone: (123) 456-7890</p>
                    <p>Email: john.doe@example.com</p>
                </div>

                <button class="unique-btn call-to-action"><a class="text-decoration-none text-white" href="contact.html">Book Now</a></button>
                
               

            </div>
        </div>
    </div>
</div>  
  

     <!-- Footer -->
     <?php include 'assets/components/footer.php'?>

    <!-- Copyright -->
    <div class="bg-dark text-center text-white py-3">
        <p class="mb-0">Copyright &copy;2024 All right reserved</p>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>