<?php

if (isset($_GET['logout']) && $_GET['logout'] == 'true') {
    // Destroy the session to log the user out
    session_destroy();

    // Optionally, redirect to the login page or another page
    header('Location: ../index.php');
    exit();
}

// Your page content goes here
?>
<nav class="menu">
        <div class="nav-top">
            <h1 class="logo"><img src="../Images/logo.png">
                <span class="logo-head"> Full State</span>
            </h1>
            <ul class="nav-ul">
                <a href="../property/property.php">
                    <li><i class="fa-solid fa-map-location-dot"></i><span class="li-head">Property</span></li>
                </a>
                <a href="../blog/blog.php">
                    <li><i class="fa-solid fa-blog"></i><span class="li-head">blogs</span></li>
                </a>
                <a href="../contact/contact.php">
                    <li><i class="fa-solid fa-comments"></i><span class="li-head">Message</span></li>
                </a>
            </ul>
        </div>
        <div class="nav-down">
            <hr>
                <a href="?logout=true"><i class="fa-solid fa-arrow-right-from-bracket"></i><span class="logout">Logout</span></a>
        </div>
</nav>