<?php
include '../backend/auth.php';
include '../backend/conn.php';
$category = isset($_GET['category']) ? $_GET['category'] : null;
$available = isset($_GET['available']) ? $_GET['available'] : null;

$sql = "SELECT * FROM `properties` WHERE 1=1";
if ($category) {
    $sql .= " AND `category` = '$category'";
}
if ($available !== null) {
    $sql .= " AND `available` = '$available'";
}
$sql .= " ORDER BY `id` DESC";
$result = mysqli_query($conn, $sql);

$unsold = "SELECT * FROM `properties` WHERE `available` = 1";
$unsoldrow = mysqli_query($conn, $unsold);
?>
<!doctype html>
<html lang="en">

<head>
    <?php include '../components/head.php' ?>
    <title>Admin | Properties</title>
</head>

<body>
    <?php include '../components/nav.php' ?>
    <section class="contact-section">
        <div class="top">
            <i class="fa-solid fa-bars menu-btn"></i>
            <div class="search-box">
                <i class="fa-solid fa-magnifying-glass"></i>
                <!-- <input type="text" id="searchInput" placeholder="Search here..."  > -->
                <input type="text" id="searchInput" placeholder="Search...">
            </div>
            <div class="right">
                <img src="../Images/profile.jpg">
            </div>
        </div>
        <div class="contact">
            <div class="page-heading">
                <div class="left">
                    <i class="fa-solid fa-map-location-dot"></i>
                    Properties
                </div>
            </div>
            <div class="box-can">
                <div class="box">
                    <i class="fa-solid fa-bars-staggered"></i>
                    <h3>Total Property</h3>
                    <h5><?php
                    $total = mysqli_query($conn, "SELECT * FROM `properties`");
                    echo mysqli_num_rows($total);
                    ?></h5>
                </div>
                <div class="box" style="background-color:#FFE6AC;">
                    <i class="fa-solid fa-check"></i>
                    <h1>Total Sold</h1>
                    <h3><?php echo mysqli_num_rows($unsoldrow) ?></h3>
                </div>
                <div class="box" style="background-color:#E7D1FC;">
                    <i class="fa-solid fa-hourglass-half"></i>
                    <h1>Pending</h1>
                    <h3>
                        <?php echo (mysqli_num_rows($total) - mysqli_num_rows($unsoldrow)) ?>
                    </h3>
                </div>
            </div>
            <!-- mutliple images -->
            <?php
            $display = '';
            $idfinal = '';
            if (isset($_GET['id']) && !empty($_GET['id'])) {
                $id = $_GET['id'];

                // Check if id is not numeric or is an empty string
                if (!is_numeric($id)) {
                    $display = 'none'; // Set display to none if id is not numeric
                }
                $idfinal = $id;
            } else {
                $display = 'none'; // Set display to none if id is not set or is empty
            }
            ?>
            <form action="../backend/backend.php" method="post" enctype="multipart/form-data" id="uploadForm"
                style="display:<?php echo $display ?>;">
                <h2 class='d-flex align-item-center justify-content-between'>
                    <span>
                        <i class="fa-solid fa-map-location-dot"></i>
                        Upload New Properties images
                    </span>
                    <span style="cursor: pointer;" class="property-form-close">
                        X
                    </span>
                </h2>
                <input type="hidden" name="id" value="<?php echo $idfinal ?>">
                <div class="mb-3">
                    <label for="images" class="form-label">Select Images</label>
                    <input type="file" class="form-control" id="images" name="images[]" multiple accept="image/*"
                        required>
                    <small id="fileError" class="form-text text-danger"></small>
                </div>
                <button type="submit" name="imagesurl" class="btn btn-primary">Upload Images</button>
            </form>
            <!-- insert form for add new properties -->
            <form id="insert" style="margin-block: 30px;" enctype="multipart/form-data" method="POST"
                action="../backend/backend.php" class="property-form">
                <h2>
                    <span>
                        <i class="fa-solid fa-map-location-dot"></i>
                        Upload New Properties
                    </span>
                    <span style="cursor: pointer;" class="property-form-close">
                        X
                    </span>
                </h2>
                <div class="mb-3">
                    <label for="image" class="form-label d-flex align-item-center justify-content-between">Cover image <span
                            class='text-danger'>* Please Insert landscape Size Image</span></label>
                    <input type="file" class="form-control" id="image" accept="image/*" name="photo" required>
                </div>

                <div class="mb-3">
                    <label for="title" class="form-label">Title</label>
                    <input type="text" class="form-control" id="title" placeholder="Enter title" name="title" required>
                </div>

                <div class="mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control" id="description" rows="3" placeholder="Enter description"
                        name="description" required></textarea>
                </div>
                <div class="mb-3 d-flex align-items-center gap-4 w-100">
                    <div class="w-100">
                        <label for="location" class="form-label">Location</label>
                        <input type="text" class="form-control " id="location" placeholder="Enter location"
                            name="location" required>
                    </div>
                    <div class="w-100">
                        <label for="city" class="form-label">City</label>
                        <select name="city" id="city" class="form-select" aria-label="Select city">
                            <option value="lahore">Lahore</option>
                            <option value="faisalabad">Faisalabad</option>
                            <option value="islamabad">Islamabad</option>
                            <option value="okara">Okara</option>
                        </select>
                    </div>
                </div>
                <div class="mb-3 d-flex align-items-center gap-4 w-100">
                    <div class="w-100">
                        <label for="bedroom" class="form-label">Bedroom</label>
                        <input type="number" class="form-control " id="bedroom" placeholder="Enter Bedroom"
                            name="bedroom" required>
                    </div>
                    <div class="w-100">
                        <label for="bathroom" class="form-label">Bathroom</label>
                        <input type="number" class="form-control " id="bathroom" placeholder="Enter bathroom"
                            name="bathroom" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="area" class="form-label">Area</label>
                    <input type="text" class="form-control" id="area" placeholder="Enter area" name="area" required>
                </div>
                <div class="mb-3">
                    <label for="price" class="form-label">Price</label>
                    <input type="number" class="form-control" id="price" placeholder="Enter price" name="price"
                        required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Category</label>
                    <div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="category" id="category1"
                                value="residential_rent" required>
                            <label class="form-check-label" for="category1">Residential Rent</label>
                        </div>

                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="category" id="category2"
                                value="residential_sale" required>
                            <label class="form-check-label" for="category2">Residential Sale</label>
                        </div>

                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="category" id="category3"
                                value="commertial_rent" required>
                            <label class="form-check-label" for="category3">Commercial Rent</label>
                        </div>

                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="category" id="category4"
                                value="commertial_sale" required>
                            <label class="form-check-label" for="category4">Commercial Sale</label>
                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="type" class="form-label">Type</label>
                    <select class="form-control" id="type" name="type" required>
                        <option value="">Select Type</option>
                    </select>
                </div>


                <div class="mb-3">
                    <label class="form-label d-flex align-item-center gap-4">Featured</label>

                    <div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="featured" id="yes" value="1" required>
                            <label class="form-check-label" for="yes">Yes</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="featured" id="no" value="0" required>
                            <label class="form-check-label" for="no">No</label>
                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Available</label>
                    <div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="available" id="availableTrue" value="1"
                                required>
                            <label class="form-check-label" for="availableTrue">Yes</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="available" id="availableFalse" value="0"
                                required>
                            <label class="form-check-label" for="availableFalse">No</label>
                        </div>
                    </div>
                </div>

                <button type="submit" name="psubmit" class="btn btn-primary">Submit</button>
            </form>
            <div class="activity">
                <div class="property">
                    <h1 class="table-heading"><i class="fa-solid fa-list-ul"></i>Properties List</h1>
                    <div class='d-flex align-item-center gap-4'>
                        <button class="btn btn-primary btn-md property-insert">Add New Property</button>


                        <!-- search filter -->
                        <form action="" method="get" class="d-flex align-items-center gap-2 justify-content-center">
                            <div>
                                <select name="category" id="category" class="form-select">
                                    <option value="residential_rent" <?php if (isset($_GET['category']) && $_GET['category'] == 'residential_rent')
                                        echo 'selected'; ?>>Residential Rent
                                    </option>
                                    <option value="residential_sale" <?php if (isset($_GET['category']) && $_GET['category'] == 'residential_sale')
                                        echo 'selected'; ?>>Residential Sale
                                    </option>
                                    <option value="commertial_rent" <?php if (isset($_GET['category']) && $_GET['category'] == 'commertial_rent')
                                        echo 'selected'; ?>>Commercial Rent
                                    </option>
                                    <option value="commertial_sale" <?php if (isset($_GET['category']) && $_GET['category'] == 'commertial_sale')
                                        echo 'selected'; ?>>Commercial Sale
                                    </option>
                                </select>

                            </div>
                            <div>
                                <select name="available" id="available" class="form-select">
                                    <option value="">Select Status</option>
                                    <option value="1" <?php if (isset($_GET['available']) && $_GET['available'] == '1')
                                        echo 'selected' ?>>Sold</option>
                                        <option value="0" <?php if (isset($_GET['available']) && $_GET['available'] == '0')
                                        echo 'selected' ?>>Unsold</option>
                                    </select>
                                </div>
                                <input type="submit" value="Filter" class="btn btn-primary">
                            </form>
                        </div>
                    </div>
                    <?php
                                    if (isset($_GET['status'])) {
                                        if ($_GET['status'] == 1) {
                                            echo "<div class='alert alert-success d-flex align-items-center justify-content-between'>" . $_GET['info'] . "<i class='fa-solid fa-x alert-close' style='cursor: pointer;'></i></div>";
                                        } else {
                                            echo "<div class='alert alert-danger d-flex align-items-center justify-content-between'>" . $_GET['info'] . "<i class='fa-solid fa-x alert-close' style='cursor: pointer;'></i></div>";
                                        }
                                    }
                                    ?>
                <table class="table table-striped table-hover border" id="dataTable">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Cover Image</th>
                            <th scope="col">Title</th>
                            <th scope="col">Price</th>
                            <th scope="col">City</th>
                            <th scope="col">Location</th>
                            <th scope="col">Area</th>
                            <th scope="col">Catorage</th>
                            <th scope="col">Type</th>
                            <th scope="col">Featured</th>
                            <th scope="col">Available</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="tableBody">
                        <?php
                        while ($row = mysqli_fetch_assoc($result)) {
                            $propertyId = $row['id'];

                            // Count the number of images associated with this property
                            $imgCountQuery = "SELECT COUNT(*) as img_count FROM imgAddress WHERE property_id = '$propertyId'";
                            $imgCountResult = mysqli_query($conn, $imgCountQuery);
                            $imgCountRow = mysqli_fetch_assoc($imgCountResult); // Fetch the count
                            $imgCount = $imgCountRow['img_count'];

                            $imgdisplay = 'block'; // Default to block (visible)
                            if ($imgCount >= 5) { // If 5 or more images, hide the button
                                $imgdisplay = 'none';
                            }

                            echo '<tr>
    <th scope="row" class="td-row"></th>
    <td><img src="' . $row['imgAddress'] . '" width="100" height="100" style="object-fit: cover;"></td>
    <td class="search-item">' . $row['title'] . '</td>
    <td>' . $row['price'] . '</td>
    <td>' . $row['city'] . '</td>
    <td>' . $row['location'] . '</td>
    <td>' . $row['area'] . '</td>
    <td><span class="btn btn-primary btn-sm">' . $row['category'] . '</span></td>
    <td><span class="btn btn-primary btn-sm">' . $row['type'] . '</span></td>
    <td><span class="btn btn-primary btn-sm">' . ($row['featured'] == 0 ? 'No' : 'Yes') . '</span></td>
    <td>
        <form action="../backend/backend.php" style="margin-block:5px;" method="POST">
            <input type="hidden" name="id" value="' . $row['id'] . '" />
            <input type="hidden" name="available" value="' . ($row['available'] == 0 ? 1 : 0) . '" />
            <input type="submit" value="' . ($row['available'] == 0 ? 'yes' : 'no') . '" class="btn btn-primary btn-sm" />
        </form>
    </td>
    <td class="action">
        <a href="?id=' . $row['id'] . '" class="btn btn-primary btn-sm" style="display:' . $imgdisplay . ';">Add Images</a>
        <a href="../backend/backend.php?imgurl=' . $row['id'] . '" class="btn btn-primary btn-sm d-block">Del all Images</a>
        <a href="../property/view.php?id=' . $row['id'] . '" class="btn btn-primary btn-sm d-block">View</a>
        <a href="../property/update.php?id=' . $row['id'] . '" class="btn btn-primary btn-sm ">Edit</a>
        <a href="../backend/backend.php?action=properties&id=' . $row['id'] . '" class="btn btn-danger btn-sm">Del</a>
    </td>
</tr>';

                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
    <?php include '../components/script.php' ?>
    <script>
        const typeSelect = document.getElementById('type');
        const categories = document.getElementsByName('category');

        const options = {
            residential_rent: ['Apartment', 'House', 'Condo'],
            residential_sale: ['Villa', 'Townhouse', 'Penthouse'],
            commercial_rent: ['Office', 'Retail', 'Warehouse'],
            commercial_sale: ['Shop', 'Hotel', 'Industrial Land']
        };

        categories.forEach(category => {
            category.addEventListener('change', function () {
                // Clear existing options
                typeSelect.innerHTML = '<option value="">Select Type</option>';

                // Get the selected category value
                const selectedCategory = this.value;

                // Populate type options based on selected category
                if (options[selectedCategory]) {
                    options[selectedCategory].forEach(type => {
                        const option = document.createElement('option');
                        option.value = type;
                        option.textContent = type;
                        typeSelect.appendChild(option);
                    });
                }
            });
        });

        // Function to filter table rows based on search input
        function filterTable() {
            var input = document.getElementById('searchInput').value.toLowerCase();  // Get the search input and convert to lowercase
            var rows = document.querySelectorAll('#tableBody tr');  // Get all rows in the table body

            rows.forEach(function (row) {
                var searchItem = row.querySelector('.search-item');  // Select the search-item cell in the row
                if (searchItem) {  // Ensure the search-item exists
                    var text = searchItem.textContent.toLowerCase();  // Get the text content and convert to lowercase
                    if (text.indexOf(input) > -1) {
                        row.style.display = '';  // Show the row if it matches the search
                    } else {
                        row.style.display = 'none';  // Hide the row if it doesn't match
                    }
                }
            });
        }

        // Add event listener for the search input
        document.getElementById('searchInput').addEventListener('keyup', filterTable);

        // Function to dynamically add a row to the table
        function addRow() {
            var tableBody = document.getElementById('tableBody');
            var newRow = document.createElement('tr');

            // Example of dynamically creating a row with search-item class
            newRow.innerHTML = `
        <td class="search-item">New Item ${tableBody.children.length + 1}</td>
        <td>Other data</td>
    `;

            tableBody.appendChild(newRow);
        }

        // Call filterTable initially to ensure visibility is correct for existing rows
        filterTable();
        document.getElementById('uploadForm').addEventListener('submit', function (event) {
            var input = document.getElementById('images');
            var files = input.files;
            var maxFiles = 5; // Set your limit here

            if (files.length > maxFiles) {
                event.preventDefault(); // Prevent form submission
                document.getElementById('fileError').textContent = 'You can only upload a maximum of ' + maxFiles + ' images.';
            } else {
                document.getElementById('fileError').textContent = ''; // Clear any previous error message
            }
        });


    </script>
</body>

</html>