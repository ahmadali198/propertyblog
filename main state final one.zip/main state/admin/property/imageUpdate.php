<?php 
include '../backend/auth.php';
include '../backend/conn.php';

$id = null;
$imgUrl = null;

// Check if 'id' and 'imgurl' parameters are set
if (isset($_GET['id']) && isset($_GET['imgurl'])) {
    // Sanitize input
    $id = mysqli_real_escape_string($conn, $_GET['id']);
    $imgUrl = mysqli_real_escape_string($conn, $_GET['imgurl']);
}

?>
<!doctype html>
<html lang="en">

<head>
    <?php include '../components/head.php'?>
    <title>Admin | Properties</title>
</head>

<body>
    <?php include '../components/nav.php'?>
    <section class="contact-section">
        <div class="top">
            <i class="fa-solid fa-bars menu-btn"></i>
            <div class="right">
                <img src="../Images/profile.jpg">
            </div>
        </div>
        <div class="contact">
            <div class="page-heading">
                <div class="left">
                    <i class="fa-solid fa-map-location-dot"></i>
                    Property Image Update
                </div>
            </div>
            <div class="view">
            <form action="../backend/backend.php" method="post" enctype="multipart/form-data" id="uploadForm">
                <h2>
                    <span>
                        <i class="fa-solid fa-map-location-dot"></i>
                        Update New Images
                    </span>
                    <span style="cursor: pointer;" class="property-form-close">
                        X
                    </span>
                </h2>
                <input type="hidden" name="id" value="<?php echo $id ?>">
                <input type="hidden" name="oldimg" value="<?php echo $imgUrl?>">
                <div class="mb-3">
                    <label for="images" class="form-label">Select Images</label>
                    <input type="file" class="form-control" id="images" name="images[]" multiple accept="image/*"
                        required>
                    <small id="fileError" class="form-text text-danger"></small>
                </div>
                <button type="submit" name="imagesuploads" class="btn btn-primary">Upload Images</button>
            </form>
            </div>
        </div>
    </section>

   <?php include '../components/script.php' ?>
</body>

</html>