<?php 

$conn =mysqli_connect('localhost','root','','fullstate') or die('connection error' . mysqli_connect_error());
?>