<?php
session_start();

// Function to check if the user is logged in
function isLoggedIn() {
    return isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true;
}

// Function to check if the user is not logged in and redirect to login page
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ../index.php'); // Redirect to the login page
        exit();
    }
}

// Example of usage: Check if user is logged in and has specific access
function requireLoginAndAccess($requiredAccessLevel) {
    if (!isLoggedIn()) {
        header('Location: ../index.php'); // Redirect to the login page
        exit();
    }

    // Optionally: Check user access level here, if applicable
    // For example, you might check a user role or permissions from a database
    // Assuming you store user access level in session
    if (isset($_SESSION['access_level']) && $_SESSION['access_level'] !== $requiredAccessLevel) {
        header('Location: unauthorized.php'); // Redirect to unauthorized page
        exit();
    }
}

// Usage examples:
// To ensure user is logged in
// requireLogin();

// To ensure user is logged in and has specific access level
// requireLoginAndAccess('admin'); // 'admin' is just an example access level
?>
