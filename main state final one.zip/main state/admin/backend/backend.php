<?php

$serve = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'fullstate';
$conn = mysqli_connect('localhost', 'root', '', 'fullstate');

if (!$conn) {
    die('error' . mysqli_connect_error());
}
if (isset($_POST['psubmit'])) {
    $city = $_POST['city'];
    $bedroom = $_POST['bedroom'];
    $bathroom = $_POST['bathroom'];
    $price = $_POST['price'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $location = $_POST['location'];
    $area = $_POST['area'];
    $category = $_POST['category'];
    $available = $_POST['available'];
    $featured = $_POST['featured']; // new featured field
    $type = $_POST['type']; // new type field

    // Photo saving 
    $filename = $_FILES['photo']["name"];
    $fileaddress = "../../assets/uploads/" . $filename;
    $filetmp = $_FILES['photo']['tmp_name'];
    $filetransfer = move_uploaded_file($filetmp, $fileaddress);

    if ($filetransfer) {
        // Base SQL query
        $sql = "INSERT INTO `properties`(`title`, `description`, `price`, `bedroom`, `bathroom`, `location`, `area`, `city`, `category`, `imgAddress`, `type`) 
                VALUES ('$title','$description','$price','$bedroom','$bathroom','$location','$area','$city','$category','$fileaddress', '$type')";

        // Add the 'featured' field only if it's not 0
        if ($featured != 0) {
            $sql = "INSERT INTO `properties`(`title`, `description`, `price`, `bedroom`, `bathroom`, `location`, `area`, `city`, `category`, `imgAddress`, `featured`, `type`) 
                    VALUES ('$title','$description','$price','$bedroom','$bathroom','$location','$area','$city','$category','$fileaddress', '$featured', '$type')";
        }

        $result = mysqli_query($conn, $sql);

        if ($result) {
            header('Location: ../property/property.php?status=1&info=The new property was added successfully');
        } else {
            header('Location: ../property/property.php?status=0&info=The new property wasn\'t added successfully');
        }
    } else {
        header('Location: ../property/property.php?status=0&info=The image failed to upload');
    }
}



// mark property sold
if (isset($_POST['available'])) {
    $id = $_POST['id'];
    $sold = $_POST['available'];

    $query = "UPDATE `properties` SET `available` = '$sold' WHERE `id` = $id";
    $result = mysqli_query($conn, $query);

    if ($result) {
        header('Location: ../property/property.php?status=1&info=The property availability is updated successfully');
    } else {
        header('Location: ../property/property.php?status=0&info=The property wasn\'t updated successfully. Try again');
    }
}


// delete query 
if (isset($_GET['action'])) {
    $action = $_GET['action'];
    $id = $_GET['id'];
    if ($action == 'properties') {
        $sql = "DELETE FROM `properties` WHERE `id`= $id";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            header('Location: ../property/property.php?status=1&info=The  property deleted successfully');
        } else {
            header('Location: ../property/property.php?status=0&info=The property  doesn\'t deleted. Try Again');
        }
    }
    if ($action == 'blogs') {
        $sql = "DELETE FROM `blogs` WHERE `id`= $id";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            header('Location: ../blog/blog.php?status=1&info=The  property deleted successfully');
        } else {
            header('Location: ../blog/blog.php?status=0&info=The property  doesn\'t deleted. Try Again');
        }
    }
    if ($action == 'contact') {
        $sql = "DELETE FROM `contact` WHERE `id`= $id";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            header('Location: ../contact/contact.php?status=1&info=The  property deleted successfully');
        } else {
            header('Location: ../contact/contact.php?status=0&info=The property  doesn\'t deleted. Try Again');
        }
    }
}

if (isset($_POST['pupdate'])) {
    // Retrieve form data
    $city = $_POST['city'];
    $bedroom = $_POST['bedroom'];
    $bathroom = $_POST['bathroom'];
    $price = $_POST['price'];
    $id = $_POST['id'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $location = $_POST['location'];
    $area = $_POST['area'];
    $category = $_POST['category'];
    $available = $_POST['available'] === 'true' ? 1 : 0;

    $property = mysqli_query($conn, "SELECT imgAddress FROM `properties` WHERE `id` = $id");
    $propertyAddress = mysqli_fetch_assoc($property);

    // Retrieve the new fields
    $featured = $_POST['featured'];
    $type = $_POST['type'];

    // Handle image upload if provided
    $imageTmpPath = $_FILES['image']['tmp_name'];
    $imageName = basename($_FILES['image']['name']);
    $imagePath = "../../assets/uploads/" . $imageName; // Adjust the path as needed

    if (!empty($imageTmpPath)) {
        // If a new image is uploaded, move it to the desired folder
        if (move_uploaded_file($imageTmpPath, $imagePath)) {
            // Update query with image, type, and optionally featured
            if (file_exists($propertyAddress)) {
                unlink($propertyAddress['imgAddress']);
            }
            $sql = "UPDATE `properties` 
                SET `title` = '$title', 
                `description` = '$description', 
                `price` = '$price', 
                `bedroom` = '$bedroom', 
                `bathroom` = '$bathroom', 
                `location` = '$location', 
                `area` = '$area', 
                `city` = '$city', 
                `category` = '$category', 
                `available` = '$available', 
                `imgAddress` = '$imagePath', 
                `type` = '$type'";

            // Add featured if it's not 0
            if ($featured != 0) {
                $sql .= ", `featured` = '$featured'";
            }

            $sql .= " WHERE `id` = '$id'";
        } else {
            // Handle image upload failure
            header('location: ../property/property.php?status=0&info=Image upload failed');
            exit();
        }
    } else {
        // Update query without image
        $sql = "UPDATE `properties` 
            SET `title` = '$title', 
            `description` = '$description', 
            `price` = '$price', 
            `bedroom` = '$bedroom', 
            `bathroom` = '$bathroom', 
            `location` = '$location', 
            `area` = '$area', 
            `city` = '$city', 
            `category` = '$category', 
            `available` = '$available', 
            `type` = '$type'";

        // Add featured if it's not 0
        if ($featured != 0) {
            $sql .= ", `featured` = '$featured'";
        }

        $sql .= " WHERE `id` = '$id'";
    }

    // Execute the query
    if (mysqli_query($conn, $sql)) {
        header('location: ../property/property.php?status=1&info=Property updated successfully');
    } else {
        header('location: ../property/property.php?status=0&info=Try again, Something went wrong');
    }
}






// contact message backend


if (isset($_GET['read'])) {
    $id = $_GET['read'];
    $query = "UPDATE `contact` SET `read` = 1 WHERE `id` = $id";
    if (mysqli_query($conn, $query)) {
        header('location: ../contact/contact.php?status=1&info=Contact marked successfully');
    } else {
        header('location: ../contact/contact.php?status=0&info=Try again,Something went wrong');
    }
}



// blogs backend

if (isset($_POST['bsubmit'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    // photo saving 
    $filename = $_FILES['photo']["name"];
    $fileaddress = "../../assets/uploads/" . time() . "jpg";
    $filetmp = $_FILES['photo']['tmp_name'];
    $filetransfer = move_uploaded_file($filetmp, $fileaddress);
    if ($filetransfer) {
        $sql = "INSERT INTO `blogs`(`title`, `img`, `description`, `timestamp`) VALUES ('$title','$fileaddress','$description',current_timestamp())";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            header('Location: ../blog/blog.php?status=1&info=The new blog uploaded successfully');
        } else {
            header('Location: ../blog/blog.php?status=0&info=The new blog wasn\'t added successfully');
        }
    } else {
        header('Location: ../blog/blog.php?status=0&info=The image failed to upload');
    }
}


// blog update
if (isset($_POST['bupdate'])) {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $description = $_POST['description'];

    $imageTmpPath = $_FILES['image']['tmp_name'];
    $imageName = $_FILES['image']['name'];
    $imagePath = "../../assets/uploads/" . $imageName; // Adjust the path as needed

    $property = mysqli_query($conn, "SELECT imgAddress FROM `blogs` WHERE `id` = $id");
    $propertyAddress = mysqli_fetch_assoc($property);
    if (move_uploaded_file($imageTmpPath, $imagePath)) {
        if (file_exists($propertyAddress)) {
            unlink($propertyAddress['imgAddress']);
        }
        $sql = "UPDATE `blogs` SET `title`='$title',`img`='$imagePath',`description`='$description',`timestamp`=current_timestamp() WHERE `id` =$id";
    } else {
        $sql = "UPDATE `blogs` SET `title`='$title',`description`='$description',`timestamp`=current_timestamp() WHERE `id` =$id";
    }

    if (mysqli_query($conn, $sql)) {
        header('location: ../blog/blog.php?status=1&info=Property updated successfully');
    } else {
        header('location: ../blog/blog.php?status=0&info=Try again,Something went wrong');
    }
}




$maxImages = 5;

// Check connection
$uploadStatus = "1";
$message = "";

if (isset($_POST['imagesurl'])) {
    $propertyId = $_POST['id'];
    $imgCountQuery = "SELECT COUNT(*) as img_count FROM imgAddress WHERE property_id = '$propertyId'";
    $imgCountResult = mysqli_query($conn, $imgCountQuery);
    $imgCountRow = mysqli_num_rows($imgCountResult);
    if ($imgCountRow > 5 && $_FILES['images']['name']) {
        $uploadStatus = "0";
        $message = "The images limit is 5,You cant upload more";
    }
    // Ensure the property ID is valid
    if (!is_numeric($propertyId)) {
        $uploadStatus = "0";
        $message = "Invalid property ID.";
    } else {
        $uploadDirectory = '../../assets/uploads/';
        if (isset($_FILES['images']) && $_FILES['images']['error'][0] === UPLOAD_ERR_OK) {
            foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
                $imageName = basename($_FILES['images']['name'][$key]);
                $uploadFile = $uploadDirectory . $imageName;

                if (move_uploaded_file($tmp_name, $uploadFile)) {
                    // Insert image URL into the database
                    $imageUrl = $uploadFile;

                    // Insert image URL with the property ID into imgAddress table
                    $sql = "INSERT INTO imgAddress (property_id, foreign_img) VALUES ('$propertyId', '$imageUrl')";

                    if (!mysqli_query($conn, $sql)) {
                        $uploadStatus = "0";
                        $message = "Database error: " . mysqli_error($conn);
                        break;
                    }
                } else {
                    $uploadStatus = "0";
                    $message = "Failed to move uploaded file: " . htmlspecialchars($imageName);
                    break;
                }
            }

            if ($uploadStatus === "1") {
                $message = "Images uploaded and saved successfully.";
            }
        } else {
            $uploadStatus = "0";
            $message = "No images were uploaded or there was an error with the upload.";
        }
    }

    // Redirect to the desired location with status and message
    header("Location: ../property/property.php?status=$uploadStatus&info=" . urlencode($message));
    exit;
}
if (isset($_GET['imgurl'])) {
    $imgurl = $_GET['imgurl'];
    $imgCountQuery = "SELECT * FROM imgAddress WHERE property_id = ". $row['id'];
    $imgCountResult = mysqli_query($conn, $imgCountQuery);
    $imgCountRow = mysqli_fetch_assoc($imgCountResult);
    while ($delurl = $imgCountRow){
        unlink($delurl['foreign_img']);
    }
    $query = "DELETE FROM `imgAddress` WHERE `property_id` = $imgurl";
    $result = mysqli_query($conn, $query);

    if($result){
        header("Location: ../property/property.php?status=1&info=" . urlencode('deleted successfull'));
    }else {
        header("Location: ../property/property.php?status=0&info=" . urlencode('Something Went Wrong'));
    }
}


// image mulit update 
if (isset($_POST['imagesuploads'])) {
    // Get property ID and old image URL
    $propertyId = mysqli_real_escape_string($conn, $_POST['id']);
    $oldImg = mysqli_real_escape_string($conn, $_POST['oldimg']);
    
    // Validate property ID
    if (!is_numeric($propertyId)) {
        header("Location: ../property/property.php?status=0&info=Invalid%20property%20ID");
        exit();
    }

    // Delete old image from the server
    if (!empty($oldImg) && file_exists($oldImg)) {
        unlink($oldImg);
    }

    // Process uploaded images
    if (isset($_FILES['images']) && !empty($_FILES['images']['name'][0])) {
        $uploadDir = '../../assets/uploads/'; // Set your upload directory
        $uploadedFiles = $_FILES['images'];
        $success = true;

        // Iterate over uploaded files
        foreach ($uploadedFiles['name'] as $key => $name) {
            if ($uploadedFiles['error'][$key] === UPLOAD_ERR_OK) {
                $tmpName = $uploadedFiles['tmp_name'][$key];
                $uploadFile = $uploadDir . basename($name);
                
                // Move uploaded file to the specified directory
                if (move_uploaded_file($tmpName, $uploadFile)) {
                    $imageUrl = mysqli_real_escape_string($conn, $uploadFile);
                    
                    // Insert new image URL into imgAddress table
                    $sql = "UPDATE imgAddress SET foreign_img = '$imageUrl' WHERE property_id = '$propertyId' AND foreign_img = '$oldImg'";
                    
                    if (!mysqli_query($conn, $sql)) {
                        $success = false;
                        echo 'Database error: ' . mysqli_error($conn) . '<br>';
                    }
                } else {
                    $success = false;
                    echo 'Failed to move uploaded file: ' . htmlspecialchars($name) . '<br>';
                }
            } else {
                $success = false;
                echo 'File upload error: ' . $uploadedFiles['error'][$key] . '<br>';
            }
        }
        
        // Redirect based on success or failure
        if ($success) {
            header("Location: ../property/property.php?status=1&info=Images%20uploaded%20successfully");
        } else {
            header("Location: ../property/property.php?status=0&info=Some%20images%20failed%20to%20upload");
        }
    } else {
        header("Location: ../property/property.php?status=0&info=No%20images%20were%20uploaded");
    }
} else {
    header("Location: ../property/property.php?status=0&info=Invalid%20form%20submission");
}