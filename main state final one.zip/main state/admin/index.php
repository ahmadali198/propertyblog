<?php
session_start();

// Secure session configuration
// ini_set('session.cookie_httponly', 1);
// ini_set('session.cookie_secure', 1); // Ensure HTTPS
// ini_set('session.use_strict_mode', 1);
// ini_set('session.cookie_samesite', 'Strict');

// Set session duration to 1 week (7 days * 24 hours * 60 minutes * 60 seconds)
$session_duration = 7 * 24 * 60 * 60;

// Static credentials for login
$valid_email = 'admin@gmail.com'; // Use a valid email format
$valid_password = 'your_secure_password'; // Replace with a hashed password in a real application
$error = '';
// Handle logout
if (isset($_GET['logout']) && $_GET['logout'] === 'true') {
    session_unset();
    session_destroy();
    header('Location: ../login.php');  // Redirect to login after logout
    exit();
}

// Check if the user is already logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    // Display main page content if logged in
    header('Location: property/property.php');
    exit();
}

// Handle the form submission for login
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize and validate input
    $inputEmail = filter_var($_POST['username'], FILTER_SANITIZE_EMAIL);
    if (!filter_var($inputEmail, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
        exit();
    }
    $inputPassword = $_POST['password'];

    // Validate credentials
    if ($inputEmail === $valid_email && $inputPassword === $valid_password) {
        // Set session variables and regenerate session ID
        session_regenerate_id(true); // Prevent session fixation attacks
        $_SESSION['username'] = $inputEmail; // Store email as username
        $_SESSION['loggedin'] = true;
        setcookie(session_name(), session_id(), time() + $session_duration, "/", "", true, true); // Secure and HTTP-only cookie

        // Redirect to the main page after successful login
        header('Location: property/property.php'); // Reload the page for the main content
        exit();
    } else {
        $error = "Invalid email or password.";
    }
}

// Generate CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap">
</head>

<body>
    <section class="vh-100">
        <div class="container py-5 h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col-12 col-md-8 col-lg-6 col-xl-5">
                    <div class="card bg-dark text-white" style="border-radius: 1rem;">
                        <div class="card-body p-1 px-4 text-center">
                            <div class="mb-md-2 mt-md-2 pb-5">
                                <h2 class="fw-bold mb-2 text-uppercase">Login</h2>
                                <p class="text-white-50 mb-5">Please enter your email and password!</p>

                                <!-- Login Form -->
                                 <?php
                                    if (!empty($error)) {
                                        echo "<div class='alert alert-danger p-1 d-flex justify-content-center align-item-center'>$error</div>";
                                    }
                                 ?>
                                <form method="post" action="">
                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>" />
                                    <div class="form-outline form-white mb-4">
                                        <input type="email"  placeholder="Enter Email" id="typeEmailX" name="username" class="form-control form-control-lg" required />
                                        <label class="form-label" for="typeEmailX">Email</label>
                                    </div>

                                    <div class="form-outline form-white mb-4">
                                        <input type="password" id="typePasswordX" placeholder="Enter Password"  name="password" class="form-control form-control-lg" required />
                                        <label class="form-label" for="typePasswordX">Password</label>
                                    </div>

                                    <button class="btn btn-outline-light btn-lg px-5" type="submit">Login</button>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js"></script>
</body>

</html>