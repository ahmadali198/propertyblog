<div class="container-fluid pe-5" style="background-color: #FF573B;">
    <ul class="list-unstyled d-flex justify-content-sm-end justify-content-center  m-0 align-items-center">
        <li class="text-white fw-semibold d-none">Call Us:+923277218969</li>
        <li><img src="assets/img/facebook.png" alt=""></li>
        <li><img src="assets/img/twitter.png" alt=""></li>
        <li><img src="assets/img/linkedin.png" alt=""></li>
        <li><img src="assets/img/insta.png" alt=""></li>
    </ul>
</div>