<?php
function formatDate($dateString) {
    // Create a DateTime object from the input string
    $date = new DateTime($dateString);
    
    // Format the date as 'F j, Y' (e.g., September 2, 2024)
    return $date->format('F j, Y');
}
$id = isset($_GET['id']) ? $_GET['id'] : null;

function send404() {
    header("HTTP/1.1 404 Not Found");
    exit();
}
if (!is_numeric($id)) {
    send404();
}
include 'backend/conn.php';

$query = "SELECT * FROM `blogs` WHERE  `id` = $id";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="./assets/css/bootstrap.css">
    <link rel="stylesheet" href="blogdetail.css">
</head>

<body>
    
    <?php include 'assets/components/top.php'?>
    <?php include 'assets/components/nav.php'?>

      <div class="container blog-details-section pt-5 pb-0">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-8">
                <!-- Blog Title Section -->
                <div class="blog-header text-center mb-5">
                    <h1 class="display-4 fw-bold"><?php echo $row['title']?></h1>
                    <div class="d-flex justify-content-center align-items-center text-muted mb-3">
                        <i class="far fa-calendar-alt me-2"></i>
                        <span>Posted on <?php echo formatDate($row['timestamp']) ?> | <i class="fas fa-user me-1"></i> Admin</span>
                    </div>
                </div>

                <!-- Main Image -->
                <div class="blog-image-main mb-5 text-center">
                    <img src="<?php echo $row['img']?>" alt="Main Blog Image" class="img-fluid rounded shadow-lg">
                </div>

                <!-- Blog Content -->
                <div class="blog-content px-4">
                    <p class="lead">
                        <?php echo $row['description']?>
                    </p>
                    <!-- <div class="row g-4">
                        <div class="col-lg-6">
                            <p>With sleek architecture and a spacious layout, this villa is perfect for families and professionals alike. The large windows flood the interiors with natural light, creating a warm and inviting atmosphere. Every detail, from the high ceilings to the designer fixtures, is crafted with care.</p>
                        </div>
                        <div class="col-lg-6 text-center">
                            <img src="./assets/img/R 2 (1).jpeg" alt="Interior Image" class="img-fluid rounded shadow-sm">
                        </div>
                    </div>

                    <div class="blog-quote mt-5 text-center py-5 px-4 rounded shadow-sm bg-light position-relative">
                        <i class=" quote-icon position-absolute"></i>
                        <blockquote class="blockquote">
                            <p class="mb-0">"This villa is not just a home; it’s a lifestyle. Designed for those who want the best of both luxury and location."</p>
                        </blockquote>
                    </div>

                    <div class="row g-4 my-5">
                        <div class="col-lg-6 text-center">
                            <img src="./assets/img/R 3 (1).jpeg" alt="Living Room" class="img-fluid rounded shadow-sm">
                        </div>
                        <div class="col-lg-6">
                            <p>The villa features expansive living areas, a gourmet kitchen, and stylish bedrooms. Outside, the landscaped gardens provide the perfect space for relaxation or entertaining guests. There’s even a private swimming pool for those hot summer days.</p>
                        </div>
                    </div>

                    <div class="blog-amenities mt-5 text-center">
                        <h3 class="fw-bold mb-4">Amenities</h3>
                        <div class="row g-3">
                            <div class="col-6 col-md-4 col-lg-3">
                                <div class="amenity-item p-3 rounded shadow-sm">
                                    <i class="fas fa-swimming-pool fa-2x text-primary mb-2"></i>
                                    <p class="mb-0">Swimming Pool</p>
                                </div>
                            </div>
                            <div class="col-6 col-md-4 col-lg-3">
                                <div class="amenity-item p-3 rounded shadow-sm">
                                    <i class="fas fa-car fa-2x text-primary mb-2"></i>
                                    <p class="mb-0">Private Parking</p>
                                </div>
                            </div>
                            <div class="col-6 col-md-4 col-lg-3">
                                <div class="amenity-item p-3 rounded shadow-sm">
                                    <i class="fas fa-dumbbell fa-2x text-primary mb-2"></i>
                                    <p class="mb-0">Gym</p>
                                </div>
                            </div>
                            <div class="col-6 col-md-4 col-lg-3">
                                <div class="amenity-item p-3 rounded shadow-sm">
                                    <i class="fas fa-spa fa-2x text-primary mb-2"></i>
                                    <p class="mb-0">Spa</p>
                                </div>
                            </div>
                        </div>
                    </div> -->

                    <p class="mt-5">If you’re looking for a luxurious urban retreat, this modern villa is a perfect choice. Contact us today to schedule a private viewing and take the first step toward owning this stunning property.</p>
                </div>
            </div>
        </div>
    </div>

     <!-- Footer -->
     <?php include 'assets/components/footer.php'?>

    <!-- Copyright -->
    <div class="bg-dark text-center text-white py-3">
        <p class="mb-0">Copyright &copy;2024 All right reserved</p>
    </div>
</body>

</html>
