<?php

    $conn = mysqli_connect('localhost','root','','fullstate') or die('connection in error' . mysqli_connect_error());
    


?>